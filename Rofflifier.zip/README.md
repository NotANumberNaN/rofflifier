# Balatro Rofflifier
Turns some text into Roffle references  
Used framework from Bala-gay (https://github.com/GitNether/balagay) because I don't know how to use Lua  

List of Changes
<details>
  <summary>Text Changes</summary>
  
  * Straight Flush - Streamer Streamer  
  * Royal Flush - Royal Streamer Streamer  
  * Baron - Baron Pog Baron  
  * Joker - Jimbo  
  * Fibonacci - Fib  
  * Gros Michel - Gross Michael  
  * Space Joker - Space Man  
  * Egg - Egg.  
  * Green Joker - Grimbo  
  * Vampire  - Nancy   
  * Photograph - Photo  
  * Turtle Bean - Bean  
  * Juggler - Yuggler  
  * Lucky Cat - Cat  
  * Spare Trousers - Pants  
  * Smiley Face - :)  
  * Hanging Chad - Chad  
  * Wee Joker - Weeee  
  * Oops! All 6s - Oops!  
  * Invisible Joker - Invis  
  * Yorick - Yo Rick  
  * Hieroglyph - Back In Time  
  * Petroglyph - Further Back In Time  
  * Hermit - Hermie  
  * Wheel of Fortune - Hweel Me  
  * Hanged Man - Hung Man  
  * Endless Mode - Keep It Goin  
  * Purple Seal - Purple  
  * Ectoplasm - Ectogasm  
  * The Club - The Clurb  
  * The Head - Head  
  * Popcorn - Poopcorn  
    
  To be implemented -  
  * Stone Card - Rock  
  * Polychrome - Shiny  

  
</details>
